package my.kafka.service;

import io.micronaut.configuration.kafka.annotation.KafkaKey;
import io.micronaut.configuration.kafka.annotation.KafkaListener;
import io.micronaut.configuration.kafka.annotation.OffsetReset;
import io.micronaut.configuration.kafka.annotation.Topic;
import io.micronaut.http.annotation.Header;

import java.util.Date;

@KafkaListener(offsetReset = OffsetReset.EARLIEST)
public class MessageListener {


    @Topic("fosesindividualonepam")
    public void receive( @KafkaKey  String msg) {
        System.out.format("Retrieved msg %s",msg);
    }

}