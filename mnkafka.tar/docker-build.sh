#!/bin/sh
docker build . -t my-kafka-service
echo
echo
echo "To run the docker container execute:"
echo "    $ docker run  my-kafka-service"
